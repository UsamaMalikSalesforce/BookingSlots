import { LightningElement } from 'lwc';

export default class ImageDisplay extends LightningElement {
    imageUrl = '/sfc/servlet.shepherd/version/renditionDownload?rendition=ORIGINAL_Png&versionId=0687Q00000Mok8rQAB';

}